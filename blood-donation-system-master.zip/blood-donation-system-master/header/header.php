<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>

    <title>Blood Donation | Welcome</title>
    <link rel="stylesheet" href="./css/style.css">
  </head>

  <body>
<header>
      <h1><img src="img/blood-donation.svg" alt="" WIDTH=100 HEIGHT=80/>   Blood Donation</h1>

</header>


</body>
</html>
